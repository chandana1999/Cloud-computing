from flask import Flask,jsonify,request,Response
import json
import os,shutil
app=Flask(__name__)


@app.route('/api/v1/users',methods = ["POST"])
def addUser():
	if request.method == "POST":
		u_data = request.args.get("username")
		u_pass = request.args.get("password")
		dictionary = {}
		dictionary["username"] = u_data
		dictionary["password"] = u_pass
		path = "./data/users/users.json"
		with open(path) as json_file:
			data = json.load(json_file)
		for x in data["users"]:
			if u_data == x["username"]:
				return "already exits" 
		data['users'].append(dictionary)
		with open(path,'w') as json_file:
			data = json.dump(data,json_file,indent=4)	
		return "Added user successfully"
	else:
		return "Bad Request."
def index():
   return render_template("index.html")


@app.route('/api/v1/users/<username>',methods=["DELETE"])
def removeUser(username):
	path = "./data/users/users.json"
	with open(path) as json_file:
		data = json.load(json_file)
	length = len(data['users'])	
	data['users'][:] = [d for d in data['users'] if d.get('username') != username]
	if(len(data['users']) == length):
		return "User not exists."
	with open(path,'w') as json_file:
		data = json.dump(data,json_file,indent=4)
	return "user removed"

@app.route('/api/v1/categories',methods=["GET"])
def listCate():
	path1="./data/categories"
	files=os.listdir(path1)
	dictionary={}
	for name in files :
		if name != ".DS_Store" :
			path2=path1+"/"
			path3=path2+name
			path5=path3+"/"
			file=name+".json"
			path4=path5+file
			with open(path4) as json_file:
				data = json.load(json_file)
			length = len(data['acts'])
			dictionary[name]=length

	return jsonify(dictionary)

'''add category'''
@app.route('/api/v1/categories',methods=['POST'])
def addCategory():
	u_cat = request.args.get("categoryName")
	path1="./data/categories"
	files=os.listdir(path1)
	for name in files :
		if name == u_cat :
			return "already exits"
	path2=path1+"/"
	path3=path2+u_cat
	os.mkdir(path3)
	path4=path3+"/"
	filename=u_cat+".json"
	path5=path4+filename
	a=open(path5,"w+")
	data = {"acts" : [ {
	
	}]}
	with open(path5,'w') as json_file:
		data = json.dump(data,json_file,indent=4)
	a.close()
	return "created"



'''remove category'''
@app.route('/api/v1/categories/<categoryName>',methods=['DELETE'])
def removeCategory(categoryName):
	path1="./data/categories"
	files=os.listdir(path1)
	a=0
	for name in files :
		if(name == categoryName):
			a=1
			path2=path1+"/"
			path3=path2+categoryName
			shutil.rmtree(path3)
		else:
			a=0

	if a==1:
		return "removed successfully"
	else:
		return "not found"


@app.route('/api/v1/categories/<categoryName>/acts/size',methods=["GET"])
def numActs(categoryName):
	path1="./data/categories"
	files=os.listdir(path1)
	a=0
	for name in files :
		if(name == categoryName):
			a=1
			path2=path1+"/"
			path3=path2+categoryName
			path5=path3+"/"
			file=categoryName+".json"
			path4=path5+file
			with open(path4) as json_file:
				data = json.load(json_file)
			length = len(data['acts'])	
			return str(length)
		else:
			a=0

	if a==0:
		return "category not found"


@app.route('/api/v1/categories/<categoryName>/acts',methods=["GET"])
def cateList(categoryName):
	path1="./data/categories"
	files=os.listdir(path1)
	a=0
	for name in files :
		if(name == categoryName):
			a=1
			path2=path1+"/"
			path3=path2+categoryName
			path5=path3+"/"
			file=categoryName+".json"
			path4=path5+file
			with open(path4) as json_file:
				data = json.load(json_file)
			return jsonify(data["acts"])
			break
		else:
			a=0

	if a==0:
		return "category not found"


@app.route('/api/v1/categories/<categoryName>/acts?start=<startRange>& end=<endRange>',methods=["GET"])
def categoryList(startRange,endRange,categoryName):
	path1="./data/categories"
	files=os.listdir(path1)
	a=0
	data1 = {"acts" : [ 
	]}
	start=int(startRange)
	end=int(endRange)
	for name in files :
		if(name == categoryName):
			a=1
			path2=path1+"/"
			path3=path2+categoryName
			path5=path3+"/"
			file=categoryName+".json"
			path4=path5+file
			with open(path4) as json_file:
				data = json.load(json_file)
			x=data["acts"]
			while start <= end :
				data1['acts'].append(x[start])
				start +=1
			break
		else:
			a=0

	if a==0:
		print("category not found")
	else:
		return jsonify(data1["acts"])



@app.route('/api/v1/acts/upvote',methods=["POST"])
def upvoteAct():
	act_id = request.args.get("idAct")
	path1="./data/categories"
	files=os.listdir(path1)
	a=0
	for name in files :
		if name != ".DS_Store" :
			path2=path1+"/"
			path3=path2+name
			path5=path3+"/"
			file=name+".json"
			path4=path5+file
			with open(path4) as json_file:
				data = json.load(json_file)
			for x in data["acts"] :
				if act_id == x["actId"] :
					a=1
					update=x["upvote"]+1
					x["upvote"]=update
					with open(path4,'w') as json_file:
						data = json.dump(data,json_file,indent=4)
					return "successfull!"
	


@app.route('/api/v1/acts/<actId>',methods=["DELETE"])
def deleteAct(actId):
	path1="./data/categories"
	files=os.listdir(path1)
	for name in files :
		if name != ".DS_Store" :
			path2=path1+"/"
			path3=path2+name
			path5=path3+"/"
			file=name+".json"
			path4=path5+file
			with open(path4) as json_file:
				data = json.load(json_file)
			length = len(data['acts'])
			data['acts'][:] = [d for d in data['acts'] if d.get('actId') != actId]
			if(len(data['acts']) == length):
				return "act not exists"
			with open(path4,'w') as json_file:
				data = json.dump(data,json_file,indent=4)
			return "act removed"



@app.route('/api/v1/acts',methods=["POST"])
def uploadAct():
	b=0
	uActId = request.args.get("IdAct")
	uUserName = request.args.get("UserName")
	UImb64 = request.args.get("imb64")
	UTimeStamp = request.args.get("TimeStamp")
	UcategoryName = request.args.get("categoryName")
	UCpation = request.args.get("Caption")

	dictionary={}
	dictionary["actId"] = uActId
	dictionary["username"] = uUserName
	dictionary["imgB64"] = UImb64
	dictionary["timestamp"] = UTimeStamp
	dictionary["category"] = UcategoryName
	dictionary["caption"] = UCpation
	dictionary["upvote"]=0
	
	

	

	b_act=0
	path1="./data/categories"
	files=os.listdir(path1)
	for name in files :
		if name != ".DS_Store" :
			path2=path1+"/"
			path3=path2+name
			path5=path3+"/"
			file=name+".json"
			path4=path5+file
			with open(path4) as json_file:
				data = json.load(json_file)
			for x in data["acts"] :
				if x["actId"] == uActId :
					b_act=1

	b_user=0
	path = "./data/users/users.json"
	with open(path) as json_file:
		data = json.load(json_file)
	for x in data["users"]:
		if uUserName == x["username"]:
			b_user=1

	
	
	b_img=0
	path10="./data/categories"
	files=os.listdir(path1)
	for name in files :
		if name != ".DS_Store" :
			path20=path10+"/"
			path30=path20+name
			path50=path30+"/"
			file=name+".json"
			path40=path50+file
			with open(path40) as json_file:
				data = json.load(json_file)
			for x in data["acts"] :
				if x["imgB64"] == UImb64 :
					b_imb=1
	
	
	a=0
	files=os.listdir(path1)
	for x in files :
		if x == UcategoryName :
			a=1

	if( (b_act == 0) and (b_user == 1) and (b_img == 0 ) and a==1) :
		path51="./data/categories/"
		file34=UcategoryName+".json"
		path52=path51+UcategoryName
		path53=path52+"/"
		path54=path53+file34
		with open(path54) as json_file:
			data = json.load(json_file)
		data['acts'].append(dictionary)
		with open(path54,'w') as json_file:
			data = json.dump(data,json_file,indent=4)
		return "successfull"

	if(b_act==1) :
		return "actId exits"
	if(b_user == 0 ):
		return "username doesn't exits"
	if(b_img ==1):
		return "imgB64 exits"
	if(a==0):
		return "category not exits"



	

app.run(port=5700)
if (__name__ == __main__):
	app.debug(True)
