<!--  This code will execute when form method is set to POST  -->
<?php
	if(isset($_POST['username']))
	 {
	   $name = $_POST['username'];
	   $pwd = $_POST['password'];
	   echo "<span class='success'>User Added Successfully</span><br/>";
	   echo "User Name : <b>".$name."</b>";
	   echo "<br> <br>";
	   echo "<b> <a href='index.html'> Click Here To Home page </a> </b><br><br>";
	//prepare the data
	$data["username","password"]=array($name,$pwd);

	//format the data
	$formattedData = json_encode($data);
	
	//set the filename
	$filename = 'data/users/users.json';
	
	//open or create the file
	$handle = fopen($filename,'a');
	
	//write the data into the file
	fwrite($handle,$formattedData);
	
	//close the file
	fclose($handle);
        echo " user name saved successfully in json File";
       }
	
?>
