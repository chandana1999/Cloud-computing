create table images ( id int(3) not NULL AUTO_INCREMENT,
                      image varchar(100), image_text varchar(30),
                      image_id varchar(50) primary key);
